document.addEventListener('DOMContentLoaded', function() {
  // Inicializar o carousel
  var elems = document.querySelectorAll('.carousel');
  var instances = M.Carousel.init(elems, {
    fullWidth: true,
    indicators: true
  });
});